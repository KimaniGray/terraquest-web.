/**
 * Background Audio System for Amapiano Track
 * - Supports loading exact audio files (e.g., /amapiano_voice.mp3 or dragged-and-dropped audio)
 * - Seamless background playback on user interaction
 * - No visual UI flashing, no visual clutter
 */

let exactAudioElement: HTMLAudioElement | null = null;
let audioCtx: AudioContext | null = null;
let isPlaying = false;
let stepIndex = 0;
let loopTimer: number | null = null;
let masterGain: GainNode | null = null;
let currentVolume = 0.70;
let hasExactFileLoaded = false;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

function getMasterGain(ctx: AudioContext): GainNode {
  if (!masterGain) {
    masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(currentVolume, ctx.currentTime);
    masterGain.connect(ctx.destination);
  }
  return masterGain;
}

/**
 * Attempt to load and play an exact audio file
 */
function tryLoadExactAudio(): void {
  if (typeof window === 'undefined') return;
  if (exactAudioElement) return;

  try {
    const audio = new Audio('/amapiano_voice.mp3');
    audio.loop = true;
    audio.volume = currentVolume;

    audio.addEventListener('canplaythrough', () => {
      hasExactFileLoaded = true;
      exactAudioElement = audio;
      if (isPlaying) {
        stopSynthBeat();
        audio.play().catch(() => {});
      }
    });

    audio.addEventListener('error', () => {
      hasExactFileLoaded = false;
    });

    audio.load();
  } catch {
    hasExactFileLoaded = false;
  }
}

// Drag & drop support to allow dropping the exact audio file directly onto the browser window
if (typeof window !== 'undefined') {
  window.addEventListener('dragover', (e) => {
    e.preventDefault();
  });

  window.addEventListener('drop', (e) => {
    e.preventDefault();
    if (e.dataTransfer && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('audio/') || file.name.match(/\.(mp3|wav|m4a|aac|ogg)$/i)) {
        try {
          const url = URL.createObjectURL(file);
          if (exactAudioElement) {
            exactAudioElement.pause();
          }
          const audio = new Audio(url);
          audio.loop = true;
          audio.volume = currentVolume;
          exactAudioElement = audio;
          hasExactFileLoaded = true;
          stopSynthBeat();
          audio.play().catch(() => {});
          isPlaying = true;
        } catch {
          // fallback
        }
      }
    }
  });

  tryLoadExactAudio();
}

/**
 * Synthesize signature Amapiano Log Drum sound
 */
function playLogDrum(pitchFreq = 55, duration = 0.35, accent = 1.0): void {
  const ctx = getAudioContext();
  if (!ctx) return;
  const master = getMasterGain(ctx);
  const now = ctx.currentTime;

  const subOsc = ctx.createOscillator();
  const subGain = ctx.createGain();
  subOsc.type = 'triangle';

  subOsc.frequency.setValueAtTime(pitchFreq * 2.2, now);
  subOsc.frequency.exponentialRampToValueAtTime(pitchFreq * 1.05, now + 0.05);
  subOsc.frequency.exponentialRampToValueAtTime(pitchFreq * 0.9, now + duration);

  const bodyFilter = ctx.createBiquadFilter();
  bodyFilter.type = 'lowpass';
  bodyFilter.frequency.setValueAtTime(320, now);
  bodyFilter.Q.setValueAtTime(6.0, now);

  subGain.gain.setValueAtTime(0.001, now);
  subGain.gain.linearRampToValueAtTime(0.7 * accent, now + 0.008);
  subGain.gain.exponentialRampToValueAtTime(0.4 * accent, now + 0.08);
  subGain.gain.exponentialRampToValueAtTime(0.001, now + duration);

  subOsc.connect(bodyFilter);
  bodyFilter.connect(subGain);
  subGain.connect(master);

  subOsc.start(now);
  subOsc.stop(now + duration);

  const clickOsc = ctx.createOscillator();
  const clickGain = ctx.createGain();
  clickOsc.type = 'square';
  clickOsc.frequency.setValueAtTime(680, now);
  clickOsc.frequency.exponentialRampToValueAtTime(120, now + 0.02);

  const clickFilter = ctx.createBiquadFilter();
  clickFilter.type = 'bandpass';
  clickFilter.frequency.setValueAtTime(500, now);
  clickFilter.Q.setValueAtTime(2.5, now);

  clickGain.gain.setValueAtTime(0.25 * accent, now);
  clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.025);

  clickOsc.connect(clickFilter);
  clickFilter.connect(clickGain);
  clickGain.connect(master);

  clickOsc.start(now);
  clickOsc.stop(now + 0.03);
}

function playShaker(accent = 0.5): void {
  const ctx = getAudioContext();
  if (!ctx) return;
  const master = getMasterGain(ctx);
  const now = ctx.currentTime;

  const bufferSize = ctx.sampleRate * 0.04;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = Math.random() * 2 - 1;
  }

  const noise = ctx.createBufferSource();
  noise.buffer = buffer;

  const filter = ctx.createBiquadFilter();
  filter.type = 'bandpass';
  filter.frequency.setValueAtTime(5200, now);
  filter.Q.setValueAtTime(3.2, now);

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.12 * accent, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.038);

  noise.connect(filter);
  filter.connect(gain);
  gain.connect(master);

  noise.start(now);
}

function playKick(): void {
  const ctx = getAudioContext();
  if (!ctx) return;
  const master = getMasterGain(ctx);
  const now = ctx.currentTime;

  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(125, now);
  osc.frequency.exponentialRampToValueAtTime(42, now + 0.08);

  gain.gain.setValueAtTime(0.6, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

  osc.connect(gain);
  gain.connect(master);

  osc.start(now);
  osc.stop(now + 0.16);
}

function playRhodesChord(freqs: number[]): void {
  const ctx = getAudioContext();
  if (!ctx) return;
  const master = getMasterGain(ctx);
  const now = ctx.currentTime;
  const duration = 0.22;

  freqs.forEach((freq) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);

    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    lfo.frequency.setValueAtTime(4.5, now);
    lfoGain.gain.setValueAtTime(3, now);
    lfo.connect(osc.frequency);
    lfo.start(now);
    lfo.stop(now + duration);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.08, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    osc.connect(gain);
    gain.connect(master);

    osc.start(now);
    osc.stop(now + duration);
  });
}

function playVocalLead(freq: number, duration = 0.35, accent = 0.6): void {
  const ctx = getAudioContext();
  if (!ctx) return;
  const master = getMasterGain(ctx);
  const now = ctx.currentTime;

  const osc1 = ctx.createOscillator();
  const osc2 = ctx.createOscillator();
  const gain = ctx.createGain();
  const filter = ctx.createBiquadFilter();

  osc1.type = 'sine';
  osc1.frequency.setValueAtTime(freq, now);

  osc2.type = 'triangle';
  osc2.frequency.setValueAtTime(freq * 1.002, now);

  const vibrato = ctx.createOscillator();
  const vibratoGain = ctx.createGain();
  vibrato.frequency.setValueAtTime(5.2, now);
  vibratoGain.gain.setValueAtTime(0, now);
  vibratoGain.gain.linearRampToValueAtTime(3.2, now + 0.12);
  vibrato.connect(osc1.frequency);
  vibrato.connect(osc2.frequency);
  vibrato.start(now);
  vibrato.stop(now + duration);

  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(1600, now);
  filter.frequency.exponentialRampToValueAtTime(750, now + duration);

  gain.gain.setValueAtTime(0.001, now);
  gain.gain.linearRampToValueAtTime(0.16 * accent, now + 0.035);
  gain.gain.setValueAtTime(0.13 * accent, now + duration * 0.7);
  gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

  osc1.connect(filter);
  osc2.connect(filter);
  filter.connect(gain);
  gain.connect(master);

  osc1.start(now);
  osc2.start(now);
  osc1.stop(now + duration);
  osc2.stop(now + duration);
}

const CHORD_PROGRESSIONS = [
  [293.66, 349.23, 440.0, 523.25, 659.25], // Dm9
  [196.0, 233.08, 293.66, 349.23],         // Gm7
  [220.0, 261.63, 329.63, 392.0],          // Am7
  [233.08, 293.66, 349.23, 440.0],         // Bbmaj7
];

const VOCAL_MELODY_PATTERN: { [stepIn64: number]: { freq: number; dur: number; accent: number } } = {
  0: { freq: 440.0, dur: 0.35, accent: 0.7 },
  3: { freq: 523.25, dur: 0.42, accent: 0.8 },
  6: { freq: 440.0, dur: 0.3, accent: 0.65 },
  8: { freq: 392.0, dur: 0.35, accent: 0.7 },
  11: { freq: 349.23, dur: 0.55, accent: 0.75 },
  16: { freq: 392.0, dur: 0.32, accent: 0.7 },
  19: { freq: 440.0, dur: 0.4, accent: 0.8 },
  22: { freq: 392.0, dur: 0.3, accent: 0.65 },
  24: { freq: 349.23, dur: 0.38, accent: 0.7 },
  27: { freq: 293.66, dur: 0.65, accent: 0.8 },
  32: { freq: 440.0, dur: 0.35, accent: 0.75 },
  35: { freq: 523.25, dur: 0.42, accent: 0.85 },
  38: { freq: 587.33, dur: 0.45, accent: 0.9 },
  42: { freq: 523.25, dur: 0.38, accent: 0.75 },
  44: { freq: 440.0, dur: 0.6, accent: 0.8 },
  48: { freq: 392.0, dur: 0.35, accent: 0.75 },
  51: { freq: 440.0, dur: 0.4, accent: 0.85 },
  54: { freq: 349.23, dur: 0.35, accent: 0.7 },
  56: { freq: 392.0, dur: 0.42, accent: 0.8 },
  60: { freq: 349.23, dur: 0.85, accent: 0.95 },
};

const STEP_MS = Math.round((60000 / 113) / 4);

const LOG_DRUM_PATTERN: { [step: number]: { pitch: number; dur: number; accent: number } } = {
  0: { pitch: 58, dur: 0.35, accent: 1.0 },
  3: { pitch: 58, dur: 0.22, accent: 0.8 },
  6: { pitch: 65, dur: 0.25, accent: 0.85 },
  8: { pitch: 52, dur: 0.38, accent: 1.0 },
  10: { pitch: 52, dur: 0.18, accent: 0.7 },
  11: { pitch: 58, dur: 0.28, accent: 0.9 },
  14: { pitch: 48, dur: 0.28, accent: 0.95 },
};

function tick(): void {
  if (!isPlaying || hasExactFileLoaded) return;

  const currentStep = stepIndex % 16;
  const stepIn64 = stepIndex % 64;
  const barIndex = Math.floor(stepIn64 / 16);

  if (currentStep % 4 === 0) playKick();
  const shakerAccent = currentStep % 4 === 2 ? 0.9 : currentStep % 2 === 1 ? 0.45 : 0.65;
  playShaker(shakerAccent);

  if (currentStep === 2 || currentStep === 10) {
    const chord = CHORD_PROGRESSIONS[barIndex % CHORD_PROGRESSIONS.length];
    playRhodesChord(chord);
  }

  const vocalNote = VOCAL_MELODY_PATTERN[stepIn64];
  if (vocalNote) {
    playVocalLead(vocalNote.freq, vocalNote.dur, vocalNote.accent);
  }

  const logHit = LOG_DRUM_PATTERN[currentStep];
  if (logHit) {
    playLogDrum(logHit.pitch, logHit.dur, logHit.accent);
  }

  stepIndex++;
}

function stopSynthBeat(): void {
  if (loopTimer) {
    clearInterval(loopTimer);
    loopTimer = null;
  }
}

export function ensureAmapianoPlaying(): void {
  if (hasExactFileLoaded && exactAudioElement) {
    if (exactAudioElement.paused) {
      exactAudioElement.play().catch(() => {});
    }
    return;
  }

  const ctx = getAudioContext();
  if (ctx && ctx.state === 'suspended') {
    ctx.resume();
  }

  if (isPlaying) return;
  isPlaying = true;
  stepIndex = 0;
  tick();
  loopTimer = window.setInterval(tick, STEP_MS);
}

// Global auto-start listener on any first user gesture in browser
if (typeof window !== 'undefined') {
  const startOnFirstInteraction = () => {
    ensureAmapianoPlaying();
    window.removeEventListener('pointerdown', startOnFirstInteraction);
    window.removeEventListener('click', startOnFirstInteraction);
    window.removeEventListener('keydown', startOnFirstInteraction);
  };

  window.addEventListener('pointerdown', startOnFirstInteraction, { once: true });
  window.addEventListener('click', startOnFirstInteraction, { once: true });
  window.addEventListener('keydown', startOnFirstInteraction, { once: true });
}