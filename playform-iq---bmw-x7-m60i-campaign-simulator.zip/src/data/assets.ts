import carDarkImage from '@/src/assets/images/bmw_x7_m60i_dark_1790508794153.jpg';
import carSunsetLaunch from '@/src/assets/images/bmw_x7_sunset_launch_1790509503176.jpg';
import hudCockpitImage from '@/src/assets/images/bmw_x7_hud_cockpit_1790508806490.jpg';
import creatorAvatarImage from '@/src/assets/images/mediamk_exact_photo_1790510507279.jpg';
import playformLogoSvg from '@/src/assets/images/playformiq-logo.svg';

export const ASSETS = {
  carDark: carDarkImage,
  carSunset: carSunsetLaunch,
  hudCockpit: hudCockpitImage,
  creatorAvatar: creatorAvatarImage,
  playformLogo: playformLogoSvg,
  rawPaths: {
    x7DarkImage: '/bmw_x7_m60i_dark.jpg',
    x7Image: '/X7 Image.png',
    atmediamk: '/atmediamk (1).jpg',
    playformLogo: '/playformiq-logo.svg',
  },
  bmwLogo: 'https://upload.wikimedia.org/wikipedia/commons/4/44/BMW.svg',
};

