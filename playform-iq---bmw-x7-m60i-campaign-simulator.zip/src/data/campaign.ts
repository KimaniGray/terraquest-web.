export interface FunnelStep {
  id: number;
  title: string;
  subtitle: string;
  shortDesc: string;
  tag: string;
}

export const FUNNEL_STEPS: FunnelStep[] = [
  {
    id: 1,
    title: 'Instagram Reel',
    subtitle: '@mediamk 20-Q hook',
    shortDesc: '“Apparently BMW thinks I don’t know this car...” script with 1,850 Pts benchmark.',
    tag: 'Traffic Engine',
  },
  {
    id: 2,
    title: 'Comments Trigger',
    subtitle: "Auto-DM keyword 'PLAY'",
    shortDesc: 'Instant intent detection when user comments the trigger keyword.',
    tag: 'Intent Detection',
  },
  {
    id: 3,
    title: 'Direct Message Bot',
    subtitle: 'Instant dispatch card',
    shortDesc: 'Sub-second auto-dispatch card delivering gamified session token.',
    tag: 'Automated Dispatch',
  },
  {
    id: 4,
    title: 'Playform HUD Quiz',
    subtitle: 'BMW telemetry gamification',
    shortDesc: 'M-Performance cockpit interactive challenge beating 1,850 pts.',
    tag: 'Gamified Experience',
  },
  {
    id: 5,
    title: 'VIP Viral Reward',
    subtitle: 'Story sticker & leaderboard',
    shortDesc: 'Viral co-branded story sticker, leaderboard pass, and VIP VIP rewards.',
    tag: 'Viral Loop',
  },
];

export const CAMPAIGN_METRICS = {
  name: 'BMW X7 Trivia Campaign',
  benchmarkPts: 1850,
  creatorHandle: '@mediamk',
  autoDispatchLatency: '0.38s',
  engagementRate: '68.4%',
  conversions: [
    { label: 'Reel Comment to DM', value: 68.4, color: '#ffa800' },
    { label: 'DM Link to HUD Open', value: 92.1, color: '#a5cfc2' },
    { label: '20-Q Quiz Completion', value: 84.2, color: '#76dc18' },
    { label: 'IG Story Viral Reshare', value: 41.8, color: '#ffb956' },
  ],
  partner: {
    creator: {
      name: '@mediamk',
      role: 'Automotive Content Creator',
      followers: '840K',
      badge: 'Verified',
    },
    vehicle: {
      model: 'BMW X7 M60i',
      engine: '4.4L TwinPower V8 • 523 HP',
      torque: '553 lb-ft',
      zeroToSixty: '4.5s',
    },
  },
};

export interface QuizQuestion {
  id: number;
  question: string;
  category: string;
  options: string[];
  correctIndex: number;
  telemetryMetric: string;
  pts: number;
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: 'What is the peak power output of the BMW X7 M60i 4.4L TwinPower V8 engine?',
    category: 'POWERTRAIN TELEMETRY',
    options: ['456 HP / 480 Nm', '523 HP / 750 Nm', '617 HP / 800 Nm', '375 HP / 520 Nm'],
    correctIndex: 1,
    telemetryMetric: 'RPM: 5,500 · BOOST: 1.4 BAR',
    pts: 180,
  },
  {
    id: 2,
    question: 'Which active chassis system dynamically counters lateral body roll in high-speed maneuvers?',
    category: 'M SPORT CHASSIS',
    options: ['Active Roll Stabilization (ARS)', 'Dynamic Hill Descent', 'Manual Sway Disconnect', 'Standard Coil Springs'],
    correctIndex: 0,
    telemetryMetric: 'LATERAL G: 0.94G · STAB: 100%',
    pts: 210,
  },
  {
    id: 3,
    question: 'What is the factory 0-60 mph launch control benchmark for the BMW X7 M60i?',
    category: 'LAUNCH DYNAMICS',
    options: ['5.8 seconds', '4.5 seconds', '3.8 seconds', '6.1 seconds'],
    correctIndex: 1,
    telemetryMetric: 'LAUNCH: xDrive 40/60 BIAS',
    pts: 200,
  },
];

export interface StoryboardScene {
  id: number;
  durationMs: number;
  spokenText: string;
  visualCut: string;
  actionNote: string;
  visualType: 'creator' | 'car' | 'quick_cuts' | 'pause' | 'score' | 'creator_challenge';
  scoreHighlight?: string;
  badgeLabel?: string;
}

export const REEL_STORYBOARD: StoryboardScene[] = [
  {
    id: 1,
    durationMs: 3800,
    spokenText: '“Apparently BMW thinks I don\'t know this car as well as I think I do.”',
    visualCut: '@mediamk Hook',
    actionNote: 'Mark Kimani addresses audience directly in luxury lounge',
    visualType: 'creator',
    badgeLabel: 'SCENE 1 // HOOK',
  },
  {
    id: 2,
    durationMs: 3400,
    spokenText: '“So they gave me a challenge.”',
    visualCut: 'Cut to the X7',
    actionNote: 'Hero cinematic cut to the BMW X7 M60i front profile',
    visualType: 'car',
    badgeLabel: 'SCENE 2 // VEHICLE CUT',
  },
  {
    id: 3,
    durationMs: 3800,
    spokenText: '“Twenty questions. They think I won\'t get them all right.”',
    visualCut: 'Quick cuts of the vehicle',
    actionNote: 'Rapid jump cuts: M kidney grille, split headlights, M cockpit HUD',
    visualType: 'quick_cuts',
    badgeLabel: 'SCENE 3 // RAPID CUTS',
  },
  {
    id: 4,
    durationMs: 2400,
    spokenText: '“I got my score.”',
    visualCut: 'Pause',
    actionNote: 'Dramatic pause, tension builds on cockpit telemetry',
    visualType: 'pause',
    badgeLabel: 'SCENE 4 // DRAMATIC PAUSE',
  },
  {
    id: 5,
    durationMs: 3600,
    spokenText: '1,850 Pts',
    visualCut: 'The score appears on screen',
    actionNote: 'High-impact golden telemetry score flash',
    visualType: 'score',
    scoreHighlight: '1,850 PTS',
    badgeLabel: 'SCENE 5 // SCORE REVEAL',
  },
  {
    id: 6,
    durationMs: 4000,
    spokenText: '“Now I want to know if you can beat me.”',
    visualCut: 'Audience Callout',
    actionNote: 'Direct challenge to viewers: comment PLAY for HUD access',
    visualType: 'creator_challenge',
    badgeLabel: 'SCENE 6 // CHALLENGE CTA',
  },
];

