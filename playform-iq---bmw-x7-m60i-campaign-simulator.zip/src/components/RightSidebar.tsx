import React from 'react';
import { TrendingUp, Gauge, CheckCircle2 } from 'lucide-react';
import { CAMPAIGN_METRICS } from '@/src/data/campaign';
import { ASSETS } from '@/src/data/assets';

export const RightSidebar: React.FC = () => {
  return (
    <aside className="w-full lg:w-[320px] flex flex-col gap-5 shrink-0">
      {/* Funnel Conversions Card */}
      <div className="flex flex-col gap-4 p-4 rounded-2xl bg-[#16161a] border border-white/5 relative overflow-hidden">
        {/* Title */}
        <div className="flex items-center justify-between">
          <h2 className="text-xs uppercase font-bold tracking-widest text-slate-300 font-display">
            Funnel Conversions
          </h2>
          <TrendingUp className="w-4 h-4 text-[#76dc18]" />
        </div>

        {/* Progress Metrics List */}
        <div className="flex flex-col gap-3.5">
          {CAMPAIGN_METRICS.conversions.map((conv, idx) => (
            <div key={idx} className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium">{conv.label}</span>
                <span className="font-bold text-white tabular-nums">{conv.value}%</span>
              </div>

              {/* Progress bar track */}
              <div className="w-full h-1.5 rounded-full bg-[#24242c] overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-700 ease-out"
                  style={{
                    width: `${conv.value}%`,
                    backgroundColor: conv.color,
                  }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* 0.38s Auto-Dispatch Highlight */}
        <div className="flex items-center gap-3 p-3 rounded-xl bg-[#1d1d24] border border-white/5 mt-1">
          <div className="w-8 h-8 rounded-lg bg-[#272733] flex items-center justify-center text-[#ffa800] shrink-0">
            <Gauge className="w-4 h-4" />
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-white">0.38s Auto-Dispatch</span>
            <span className="text-[11px] text-slate-400">Zero human dropoff bottleneck</span>
          </div>
        </div>
      </div>

      {/* Partner Integration Card */}
      <div className="flex flex-col gap-3.5 p-4 rounded-2xl bg-[#16161a] border border-white/5">
        <h2 className="text-xs uppercase font-bold tracking-widest text-slate-300 font-display">
          Partner Integration
        </h2>

        {/* Creator Row */}
        <div className="flex items-center gap-3 p-2.5 rounded-xl bg-[#1d1d24]/60 hover:bg-[#1d1d24] transition-colors border border-white/5">
          <div className="w-10 h-10 rounded-full overflow-hidden border border-white/10 shrink-0 bg-[#2b2b36]">
            <img
              src={ASSETS.creatorAvatar}
              alt="mediamk creator avatar"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = ASSETS.rawPaths.atmediamk;
              }}
            />
          </div>
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-white truncate">
                {CAMPAIGN_METRICS.partner.creator.name}
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#1da1f2]" />
            </div>
            <span className="text-[11px] text-slate-400 truncate">
              {CAMPAIGN_METRICS.partner.creator.role}
            </span>
          </div>
        </div>

        {/* Vehicle Row */}
        <div className="flex items-center gap-3 p-2.5 rounded-xl bg-[#1d1d24]/60 hover:bg-[#1d1d24] transition-colors border border-white/5">
          <div className="w-10 h-10 rounded-full bg-black border border-white/10 flex items-center justify-center font-bold text-[11px] text-white tracking-widest shrink-0">
            BMW
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-xs font-bold text-white truncate">
              {CAMPAIGN_METRICS.partner.vehicle.model}
            </span>
            <span className="text-[11px] text-slate-400 truncate">
              {CAMPAIGN_METRICS.partner.vehicle.engine}
            </span>
          </div>
        </div>
      </div>

      {/* Verification Status Card */}
      <div className="flex items-start gap-3 p-4 rounded-2xl bg-[#16161a] border border-[#76dc18]/20">
        <CheckCircle2 className="w-5 h-5 text-[#76dc18] shrink-0 mt-0.5" />
        <p className="text-xs leading-relaxed text-slate-300">
          Full client-side simulation loaded with live reactive sound chimes and native state switches.
        </p>
      </div>
    </aside>
  );
};
