import React, { useState } from 'react';
import { Share2, Award, RotateCcw, Check, Sparkles, Ticket } from 'lucide-react';
import { ASSETS } from '@/src/data/assets';
import { CAMPAIGN_METRICS } from '@/src/data/campaign';
import { playVictoryChime } from '@/src/utils/audio';
import { ensureAmapianoPlaying } from '@/src/utils/amapianoAudio';

interface ViralRewardScreenProps {
  score?: number;
  onRestart: () => void;
}

export const ViralRewardScreen: React.FC<ViralRewardScreenProps> = ({
  score = 1940,
  onRestart,
}) => {
  const [shared, setShared] = useState(false);
  const [claimedPass, setClaimedPass] = useState(false);

  const handleShare = () => {
    ensureAmapianoPlaying();
    playVictoryChime();
    setShared(true);
    setTimeout(() => setShared(false), 3000);
  };

  const handleClaimPass = () => {
    ensureAmapianoPlaying();
    setClaimedPass(true);
  };

  return (
    <div className="relative w-full h-full bg-[#0d0d12] flex flex-col justify-between text-white overflow-hidden select-none">
      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-44 h-44 bg-[#ffa800]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-44 h-44 bg-[#76dc18]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header */}
      <div className="relative z-10 pt-10 px-4 pb-2 border-b border-white/10 flex items-center justify-between bg-[#14141a]/80 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-md bg-[#ffa800] flex items-center justify-center text-black font-bold text-xs">
            M
          </div>
          <span className="font-bold text-xs uppercase tracking-wider text-white">
            VIP Viral Rewards
          </span>
        </div>
        <button
          onClick={() => {
            ensureAmapianoPlaying();
            onRestart();
          }}
          className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* Content Area */}
      <div className="relative z-10 flex-1 overflow-y-auto p-4 flex flex-col gap-3.5">
        {/* Story Sticker Card Preview */}
        <div className="p-4 rounded-2xl bg-gradient-to-b from-[#1f1f2a] to-[#161620] border border-[#ffa800]/40 shadow-xl flex flex-col items-center text-center relative overflow-hidden">
          {/* Subtle watermark */}
          <div className="absolute top-2 left-3 text-[9px] font-mono text-slate-500 uppercase tracking-widest">
            STORY STICKER // PLAYFORM IQ
          </div>

          <div className="w-10 h-10 rounded-full border-2 border-[#ffa800] overflow-hidden mt-3 shadow-md">
            <img
              src={ASSETS.creatorAvatar}
              alt="mediamk"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = ASSETS.rawPaths.atmediamk;
              }}
            />
          </div>

          <div className="flex items-center gap-1.5 mt-2">
            <span className="text-xs font-bold text-white">@mediamk × BMW X7 M60i</span>
            <span className="w-3 h-3 rounded-full bg-[#1da1f2] flex items-center justify-center text-[7px] text-white font-bold">
              ✓
            </span>
          </div>

          {/* Telemetry Award */}
          <div className="my-2 flex flex-col items-center">
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#76dc18] font-bold">
              BENCHMARK CRUSHED!
            </span>
            <div className="text-3xl font-extrabold font-display text-white tracking-tight flex items-baseline gap-1">
              <span>{score}</span>
              <span className="text-sm font-mono text-[#ffa800]">PTS</span>
            </div>
            <span className="text-[11px] text-slate-300">
              Ranked <span className="text-[#76dc18] font-bold">Top 3%</span> Global Driver Telemetry
            </span>
          </div>

          {/* Story Prompt Chip */}
          <div className="px-3 py-1 rounded-full bg-black/60 border border-white/10 text-[10px] text-slate-300 font-medium">
            "I beat @mediamk's 1,850 pts mark! Can anyone beat {score}?"
          </div>
        </div>

        {/* Share Feedback Toast */}
        {shared && (
          <div className="p-2.5 rounded-xl bg-[#1b3524] border border-[#76dc18] flex items-center justify-between text-xs text-[#76dc18] animate-in fade-in">
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4" />
              <span>Story Sticker shared to Instagram!</span>
            </div>
            <Sparkles className="w-4 h-4 animate-spin" />
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2">
          {/* Share to IG Story */}
          <button
            onClick={handleShare}
            className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#ffa800] to-[#ffb932] text-black font-bold text-xs flex items-center justify-center gap-1.5 shadow-md hover:brightness-110 active:scale-98 transition-all"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share to Story</span>
          </button>

          {/* Claim VIP Pass */}
          <button
            onClick={handleClaimPass}
            className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
              claimedPass
                ? 'bg-[#1b3524] border-[#76dc18] text-[#76dc18]'
                : 'bg-[#20202a] border-white/10 text-white hover:bg-[#282834]'
            }`}
          >
            <Ticket className="w-3.5 h-3.5" />
            <span>{claimedPass ? 'Pass Claimed' : 'VIP Track Pass'}</span>
          </button>
        </div>

        {/* Mini Leaderboard View */}
        <div className="flex flex-col gap-2 p-3 rounded-xl bg-[#161620] border border-white/5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-display flex items-center gap-1">
              <Award className="w-3 h-3 text-[#ffa800]" />
              Campaign Telemetry Leaderboard
            </span>
            <span className="text-[10px] text-slate-500 font-mono">LIVE</span>
          </div>

          <div className="flex flex-col gap-1.5 text-xs">
            {/* Rank 1 */}
            <div className="flex items-center justify-between p-1.5 rounded-lg bg-[#1f1f2c]/60">
              <span className="text-slate-300">1. @alex_trackday</span>
              <span className="font-mono font-bold text-white">1,980 pts</span>
            </div>

            {/* Rank 2 - YOU */}
            <div className="flex items-center justify-between p-1.5 rounded-lg bg-[#27261a] border border-[#ffa800]/40">
              <span className="font-bold text-[#ffa800] flex items-center gap-1">
                2. YOU (Current Driver) 🏆
              </span>
              <span className="font-mono font-bold text-[#ffa800]">{score} pts</span>
            </div>

            {/* Rank 3 - Creator Benchmark */}
            <div className="flex items-center justify-between p-1.5 rounded-lg bg-[#1f1f2c]/60">
              <span className="text-slate-300">3. {CAMPAIGN_METRICS.creatorHandle} (Benchmark)</span>
              <span className="font-mono text-slate-300">{CAMPAIGN_METRICS.benchmarkPts} pts</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Sticky Reset Bar */}
      <div className="relative z-10 p-3 bg-[#14141a] border-t border-white/10 flex items-center justify-between">
        <span className="text-[11px] text-slate-400">
          Funnel cycle completed (5 of 5 steps)
        </span>
        <button
          onClick={() => {
            ensureAmapianoPlaying();
            onRestart();
          }}
          className="text-xs font-bold text-[#ffa800] hover:underline"
        >
          Re-run Simulator
        </button>
      </div>
    </div>
  );
};
