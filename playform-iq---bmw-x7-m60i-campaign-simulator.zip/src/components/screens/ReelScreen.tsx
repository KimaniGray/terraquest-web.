import React, { useState, useEffect, useRef } from 'react';
import {
  Heart,
  MessageCircle,
  Send,
  Flag,
  ChevronDown,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Zap,
  Film,
  X,
  CheckCircle2,
} from 'lucide-react';
import { ASSETS } from '@/src/data/assets';
import { REEL_STORYBOARD, StoryboardScene } from '@/src/data/campaign';
import {
  playEngineRev,
  playWhooshCut,
  playScoreImpact,
  playTelemetryBeep,
} from '@/src/utils/audio';
import { ensureAmapianoPlaying } from '@/src/utils/amapianoAudio';

interface ReelScreenProps {
  onOpenComments: () => void;
  onLaunchChallenge: () => void;
}

export const ReelScreen: React.FC<ReelScreenProps> = ({
  onOpenComments,
  onLaunchChallenge,
}) => {
  const [currentSceneIdx, setCurrentSceneIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [sceneProgress, setSceneProgress] = useState(0); // 0 to 100
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(84200);
  const [following, setFollowing] = useState(false);
  const [showHearts, setShowHearts] = useState(false);
  const [soundMuted, setSoundMuted] = useState(false);
  const [showScriptDrawer, setShowScriptDrawer] = useState(false);

  const sceneTimerRef = useRef<number | null>(null);

  const safeSceneIdx = Math.max(0, Math.min(currentSceneIdx, (REEL_STORYBOARD?.length || 1) - 1));
  const activeScene: StoryboardScene = REEL_STORYBOARD[safeSceneIdx] || REEL_STORYBOARD[0];

  // Sound triggers on scene switch
  useEffect(() => {
    if (!isPlaying || !activeScene) return;

    if (!soundMuted) {
      if (activeScene.id === 2) {
        // Cut to X7
        playWhooshCut();
        setTimeout(() => playEngineRev(0.2), 150);
      } else if (activeScene.id === 3) {
        // Quick cuts
        playWhooshCut();
      } else if (activeScene.id === 5) {
        // Score appears!
        playScoreImpact();
      } else if (activeScene.id === 6) {
        // Callout
        playTelemetryBeep(1100, 0.1, 0.2);
      }
    }
  }, [safeSceneIdx, soundMuted, isPlaying]);

  // Main playback timer loop
  useEffect(() => {
    if (!isPlaying) return;

    const intervalStep = 50; // update every 50ms
    const totalSteps = Math.max(1, Math.round((activeScene?.durationMs || 3000) / intervalStep));
    let stepCount = 0;

    sceneTimerRef.current = window.setInterval(() => {
      stepCount++;
      const pct = Math.min(100, (stepCount / totalSteps) * 100);
      setSceneProgress(pct);

      if (stepCount >= totalSteps) {
        // Advance to next scene cleanly using modulo
        setCurrentSceneIdx((prev) => (prev + 1) % (REEL_STORYBOARD.length || 1));
        setSceneProgress(0);
      }
    }, intervalStep);

    return () => {
      if (sceneTimerRef.current) clearInterval(sceneTimerRef.current);
    };
  }, [safeSceneIdx, isPlaying, activeScene?.durationMs]);

  const handleTogglePlay = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    ensureAmapianoPlaying();
    setIsPlaying(!isPlaying);
  };

  const handleJumpToScene = (idx: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    ensureAmapianoPlaying();
    const safe = Math.max(0, Math.min(idx, (REEL_STORYBOARD?.length || 1) - 1));
    setCurrentSceneIdx(safe);
    setSceneProgress(0);
  };

  const handleLike = () => {
    ensureAmapianoPlaying();
    if (!liked) {
      setLiked(true);
      setLikesCount((prev) => prev + 1);
      setShowHearts(true);
      setTimeout(() => setShowHearts(false), 1200);
    } else {
      setLiked(false);
      setLikesCount((prev) => prev - 1);
    }
  };

  const formatCount = (count: number) => {
    return `${(count / 1000).toFixed(1)}K`;
  };

  // Determine active media visual based on script cuts
  const getActiveMediaContent = () => {
    switch (activeScene.visualType) {
      case 'creator':
        // Scene 1: Mark Kimani speaking
        return (
          <div className="relative w-full h-full overflow-hidden bg-black flex items-center justify-center">
            <img
              src={ASSETS.creatorAvatar}
              alt="mediamk speaking"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-top scale-105 transition-transform duration-1000"
              onError={(e) => {
                (e.target as HTMLImageElement).src = ASSETS.rawPaths.atmediamk;
              }}
            />
            {/* Cinematic camera lens breathing effect */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/60 pointer-events-none" />
          </div>
        );

      case 'car':
        // Scene 2: Cut to the X7 (Steady, no pulse)
        return (
          <div className="relative w-full h-full overflow-hidden bg-black">
            <img
              src={ASSETS.carDark}
              alt="BMW X7 M60i Cut"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-black/60 pointer-events-none" />
          </div>
        );

      case 'quick_cuts':
        // Scene 3: Vehicle Curved Cockpit Showcase (Steady, no flashing cuts)
        return (
          <div className="relative w-full h-full overflow-hidden bg-black">
            <img
              src={ASSETS.hudCockpit}
              alt="X7 M Curved Cockpit"
              className="w-full h-full object-cover object-center scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-black/60 pointer-events-none" />
          </div>
        );

      case 'pause':
        // Scene 4: Dramatic Pause
        return (
          <div className="relative w-full h-full overflow-hidden bg-black flex items-center justify-center">
            <img
              src={ASSETS.hudCockpit}
              alt="Telemetry Pause"
              className="w-full h-full object-cover object-center brightness-75 scale-100"
            />
            {/* Vignette focused spotlight */}
            <div className="absolute inset-0 bg-radial-gradient from-transparent via-black/50 to-black/90 pointer-events-none" />
          </div>
        );

      case 'score':
        // Scene 5: The score appears on screen! 1,850 Pts
        return (
          <div className="relative w-full h-full overflow-hidden bg-black flex items-center justify-center">
            <img
              src={ASSETS.carDark}
              alt="BMW X7"
              className="w-full h-full object-cover object-center brightness-40 blur-[2px] scale-105"
            />
            <div className="absolute inset-0 bg-black/60" />

            {/* Huge Golden Telemetry Score Banner */}
            <div className="relative z-20 flex flex-col items-center justify-center px-6 py-5 rounded-3xl bg-[#14141a]/95 border-2 border-[#ffa800] shadow-[0_0_50px_rgba(255,168,0,0.5)] transform animate-bounce-subtle">
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ffa800]/20 text-[#ffa800] text-[10px] font-mono font-bold tracking-widest uppercase mb-1">
                <Sparkles className="w-3.5 h-3.5 animate-spin" />
                @mediamk BENCHMARK
              </div>

              <div className="font-display font-extrabold text-5xl sm:text-6xl tracking-tight text-white drop-shadow-[0_0_35px_rgba(255,168,0,0.8)] flex items-baseline gap-2">
                <span className="text-[#ffa800]">1,850</span>
                <span className="text-2xl font-mono text-[#76dc18]">PTS</span>
              </div>

              <p className="text-[11px] text-slate-300 font-mono tracking-wider uppercase mt-1">
                20 / 20 TELEMETRY CHECKS
              </p>
            </div>
          </div>
        );

      case 'creator_challenge':
        // Scene 6: Callout to audience
        return (
          <div className="relative w-full h-full overflow-hidden bg-black flex items-center justify-center">
            <img
              src={ASSETS.creatorAvatar}
              alt="mediamk Challenge"
              className="w-full h-full object-cover object-top scale-105"
              onError={(e) => {
                (e.target as HTMLImageElement).src = ASSETS.rawPaths.atmediamk;
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/60 pointer-events-none" />
          </div>
        );

      default:
        return (
          <div className="relative w-full h-full overflow-hidden bg-black">
            <img
              src={ASSETS.carDark}
              alt="BMW X7 M60i"
              className="w-full h-full object-cover object-center scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-black/60 pointer-events-none" />
          </div>
        );
    }
  };

  return (
    <div className="relative w-full h-full bg-black overflow-hidden select-none flex flex-col justify-between text-white font-sans">
      {/* Dynamic Background Media Render */}
      <div className="absolute inset-0 z-0">{getActiveMediaContent()}</div>

      {/* Floating Heart burst animation */}
      {showHearts && (
        <div className="absolute inset-0 z-30 pointer-events-none flex items-center justify-center">
          <Heart className="w-24 h-24 text-red-500 fill-red-500 animate-float-heart drop-shadow-[0_0_20px_rgba(239,68,68,0.8)]" />
        </div>
      )}

      {/* Top Section: Segmented Story Progress Bar & Navigation */}
      <div className="relative z-20 px-3 pt-3 flex flex-col gap-2">
        {/* 6 Story Segments (matching the 6 script cuts) */}
        <div className="w-full grid grid-cols-6 gap-1.5 h-1.5 pt-2">
          {REEL_STORYBOARD.map((scene, idx) => {
            let fillPct = 0;
            if (idx < currentSceneIdx) fillPct = 100;
            else if (idx === currentSceneIdx) fillPct = sceneProgress;

            return (
              <button
                key={scene.id}
                onClick={(e) => handleJumpToScene(idx, e)}
                title={`Jump to ${scene.visualCut}`}
                className="relative h-1.5 rounded-full bg-white/25 overflow-hidden group cursor-pointer"
              >
                <div
                  className="h-full bg-white transition-all duration-75 rounded-full"
                  style={{ width: `${fillPct}%` }}
                />
              </button>
            );
          })}
        </div>

        {/* Header Controls Bar */}
        <div className="flex items-center justify-between mt-1">
          {/* Reel Label & Storyboard Inspector Button */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => ensureAmapianoPlaying()}
              className="flex items-center gap-1 text-sm font-bold tracking-tight text-white hover:opacity-85"
            >
              <span>Reels</span>
              <ChevronDown className="w-3.5 h-3.5 mt-0.5" />
            </button>

            {/* Storyboard Script Toggle Pill */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowScriptDrawer(!showScriptDrawer);
              }}
              className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/60 backdrop-blur-md border border-[#ffa800]/50 text-[10px] font-bold text-[#ffa800] hover:bg-black/80 transition-all shadow-md"
            >
              <Film className="w-3 h-3" />
              <span>Script Cuts</span>
            </button>
          </div>

          {/* Right Header Controls: Sound + Play/Pause */}
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setSoundMuted(!soundMuted);
              }}
              title={soundMuted ? 'Unmute video audio' : 'Mute video audio'}
              className="p-1.5 rounded-full bg-black/40 backdrop-blur-md text-white hover:bg-black/60 transition-colors"
            >
              {soundMuted ? (
                <VolumeX className="w-4 h-4 text-red-400" />
              ) : (
                <Volume2 className="w-4 h-4 text-[#76dc18]" />
              )}
            </button>

            <button
              onClick={handleTogglePlay}
              title={isPlaying ? 'Pause Reel' : 'Play Reel'}
              className="p-1.5 rounded-full bg-black/40 backdrop-blur-md text-white hover:bg-black/60 transition-colors"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 text-[#ffa800]" />}
            </button>
          </div>
        </div>

        {/* Current Scene Badge & Cut Indicator */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-black/60 backdrop-blur-md border border-white/10 text-[9px] font-mono uppercase tracking-widest text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-[#ffa800] animate-pulse" />
            <span>{activeScene?.badgeLabel || 'SCENE'}</span>
            <span className="text-white/40">·</span>
            <span className="text-white font-semibold">{activeScene?.visualCut || ''}</span>
          </div>

          <div className="text-[10px] font-mono text-white/70 bg-black/50 px-2 py-0.5 rounded backdrop-blur-sm">
            {safeSceneIdx + 1} / {(REEL_STORYBOARD?.length || 6)}
          </div>
        </div>
      </div>

      {/* Middle Interactive Double-tap Area & Dynamic Instagram Subtitles */}
      <div
        className="relative z-10 flex-1 cursor-pointer flex flex-col items-center justify-center px-4"
        onDoubleClick={handleLike}
        onClick={() => handleTogglePlay()}
      >
        {/* Pause Overlay Indicator when paused */}
        {!isPlaying && (
          <div className="w-14 h-14 rounded-full bg-black/70 backdrop-blur-md border border-white/20 flex items-center justify-center text-white mb-4 shadow-xl">
            <Play className="w-6 h-6 fill-current ml-0.5 text-[#ffa800]" />
          </div>
        )}

        {/* Dynamic On-Screen Subtitle Card (Viral Reel Typography) */}
        <div className="max-w-[92%] px-4 py-3 rounded-2xl bg-black/65 backdrop-blur-md border border-white/15 text-center shadow-2xl transition-all duration-300">
          <p className="font-display font-bold text-base sm:text-lg leading-snug tracking-tight text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]">
            {activeScene?.spokenText || ''}
          </p>

          {activeScene?.scoreHighlight && (
            <div className="mt-2 text-3xl font-extrabold text-[#ffa800] font-mono tracking-wider drop-shadow-[0_0_20px_rgba(255,168,0,0.8)]">
              {activeScene.scoreHighlight}
            </div>
          )}
        </div>
      </div>

      {/* Script Storyboard Modal Drawer */}
      {showScriptDrawer && (
        <div className="absolute inset-0 z-40 bg-black/85 backdrop-blur-md p-4 flex flex-col justify-between animate-fade-in">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Film className="w-4 h-4 text-[#ffa800]" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-white">
                Reel Storyboard Script
              </h2>
            </div>
            <button
              onClick={() => setShowScriptDrawer(false)}
              className="p-1 rounded-full text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto py-3 flex flex-col gap-2.5">
            {REEL_STORYBOARD.map((scene, idx) => (
              <div
                key={scene.id}
                onClick={() => {
                  handleJumpToScene(idx);
                  setShowScriptDrawer(false);
                }}
                className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                  idx === currentSceneIdx
                    ? 'bg-[#1e1d15] border-[#ffa800] shadow-md'
                    : 'bg-[#15151a] border-white/5 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mb-1">
                  <span className="font-bold text-[#ffa800]">
                    SCENE {scene.id} · {scene.visualCut}
                  </span>
                  <span>{(scene.durationMs / 1000).toFixed(1)}s</span>
                </div>
                <p className="text-xs text-white font-medium italic">{scene.spokenText}</p>
                <span className="text-[10px] text-slate-400 block mt-1">
                  ↳ {scene.actionNote}
                </span>
              </div>
            ))}
          </div>

          <button
            onClick={() => setShowScriptDrawer(false)}
            className="w-full py-2 rounded-xl bg-[#ffa800] text-black font-bold text-xs uppercase tracking-wider"
          >
            Resume Playback
          </button>
        </div>
      )}

      {/* Reel Bottom & Sidebar Action Bar */}
      <div className="relative z-20 p-4 flex items-end justify-between gap-3 bg-gradient-to-t from-black via-black/80 to-transparent">
        {/* Left Side: Creator details, caption, CTA banner */}
        <div className="flex-1 flex flex-col gap-2.5 max-w-[82%]">
          {/* Creator Profile Lockup */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full border border-white/30 overflow-hidden shrink-0 bg-neutral-800">
              <img
                src={ASSETS.creatorAvatar}
                alt="mediamk"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = ASSETS.rawPaths.atmediamk;
                }}
              />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-xs tracking-tight text-white">mediamk</span>
              <span className="w-3.5 h-3.5 rounded-full bg-[#1da1f2] flex items-center justify-center text-[8px] text-white font-bold">
                ✓
              </span>
              <span className="text-white/60 text-xs">·</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  ensureAmapianoPlaying();
                  setFollowing(!following);
                }}
                className={`text-xs font-semibold px-2 py-0.5 rounded-md transition-all ${
                  following
                    ? 'bg-white/20 text-white'
                    : 'bg-transparent text-[#ffa800] hover:underline'
                }`}
              >
                {following ? 'Following' : 'Follow'}
              </button>
            </div>
          </div>

          {/* Reel Caption matching the script */}
          <p className="text-xs leading-snug text-white/95 drop-shadow-sm font-normal">
            BMW gave me a 20-question challenge. I got my score:{' '}
            <span className="font-bold text-[#ffa800]">1,850 Pts</span>. Now I want to know if you can beat me! 🏎️💨
          </p>

          {/* Interactive Trigger Banner CTA */}
          <button
            onClick={() => {
              ensureAmapianoPlaying();
              onOpenComments();
            }}
            className="w-full flex items-center justify-between py-2 px-3 rounded-full bg-[#1a1c1a]/95 backdrop-blur-md border border-[#76dc18]/50 hover:border-[#76dc18] text-left transition-all group shadow-lg shadow-black/60"
          >
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-2 h-2 rounded-full bg-[#76dc18] animate-ping" />
              <span className="text-xs font-semibold text-white truncate">
                Comment <span className="text-[#76dc18] font-bold">"PLAY"</span> to beat 1,850 pts
              </span>
            </div>
            <span className="text-xs font-bold text-[#76dc18] group-hover:translate-x-1 transition-transform">
              →
            </span>
          </button>
        </div>

        {/* Right Side: Vertical Social Engagement Column */}
        <div className="flex flex-col items-center gap-3.5 pb-1">
          {/* Like */}
          <button
            onClick={handleLike}
            className="flex flex-col items-center gap-1 group"
          >
            <div className="p-2 rounded-full bg-black/50 backdrop-blur-sm group-hover:bg-black/70 transition-colors">
              <Heart
                className={`w-6 h-6 transition-all ${
                  liked
                    ? 'text-red-500 fill-red-500 scale-110 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]'
                    : 'text-white'
                }`}
              />
            </div>
            <span className="text-[11px] font-semibold text-white/90 tabular-nums">
              {formatCount(likesCount)}
            </span>
          </button>

          {/* Comments */}
          <button
            onClick={() => {
              ensureAmapianoPlaying();
              onOpenComments();
            }}
            className="flex flex-col items-center gap-1 group"
          >
            <div className="p-2 rounded-full bg-black/50 backdrop-blur-sm group-hover:bg-black/70 transition-colors">
              <MessageCircle className="w-6 h-6 text-white group-hover:text-[#ffa800] transition-colors" />
            </div>
            <span className="text-[11px] font-semibold text-white/90 tabular-nums">
              12.9K
            </span>
          </button>

          {/* Share */}
          <button
            onClick={() => {
              ensureAmapianoPlaying();
            }}
            className="flex flex-col items-center gap-1 group"
          >
            <div className="p-2 rounded-full bg-black/50 backdrop-blur-sm group-hover:bg-black/70 transition-colors">
              <Send className="w-5 h-5 text-white" />
            </div>
            <span className="text-[11px] font-semibold text-white/90 tabular-nums">
              24.1K
            </span>
          </button>

          {/* Playform Flag Icon Trigger */}
          <button
            onClick={() => {
              ensureAmapianoPlaying();
              onLaunchChallenge();
            }}
            className="flex flex-col items-center gap-1 group"
          >
            <div className="w-9 h-9 rounded-full bg-[#1b2f23] border border-[#76dc18]/60 flex items-center justify-center text-[#76dc18] shadow-[0_0_12px_rgba(118,220,24,0.3)] group-hover:scale-105 transition-transform">
              <Flag className="w-4 h-4 fill-current" />
            </div>
            <span className="text-[10px] font-bold tracking-wider text-[#76dc18] uppercase">
              PLAY
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
