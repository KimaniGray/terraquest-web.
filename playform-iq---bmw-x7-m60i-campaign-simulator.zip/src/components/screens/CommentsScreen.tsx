import React, { useState } from 'react';
import { X, Send, Pin, Heart, Sparkles, CheckCircle2 } from 'lucide-react';
import { ASSETS } from '@/src/data/assets';
import { playNotificationPing } from '@/src/utils/audio';
import { ensureAmapianoPlaying } from '@/src/utils/amapianoAudio';

interface CommentsScreenProps {
  onAutoDmDispatched: () => void;
  onClose: () => void;
}

interface CommentItem {
  id: string;
  username: string;
  avatar: string;
  text: string;
  timeAgo: string;
  likes: number;
  isPinned?: boolean;
  isCreator?: boolean;
  hasDispatchedBadge?: boolean;
}

export const CommentsScreen: React.FC<CommentsScreenProps> = ({
  onAutoDmDispatched,
  onClose,
}) => {
  const [commentInput, setCommentInput] = useState('');
  const [comments, setComments] = useState<CommentItem[]>([
    {
      id: 'pinned-1',
      username: 'mediamk',
      avatar: ASSETS.creatorAvatar,
      text: 'BMW gave me a 20-question challenge and I got 1,850 Pts. Can you beat me? Drop PLAY below to test your driving IQ! 🏎️💨',
      timeAgo: '2h',
      likes: 3420,
      isPinned: true,
      isCreator: true,
    },
    {
      id: 'c-1',
      username: 'apex_driver',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
      text: 'That 4.4L TwinPower V8 sounds like an absolute beast! 🔥',
      timeAgo: '45m',
      likes: 182,
    },
    {
      id: 'c-2',
      username: 'marcus_m_power',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80',
      text: 'PLAY',
      timeAgo: '12m',
      likes: 24,
      hasDispatchedBadge: true,
    },
  ]);

  const [dispatchedAlert, setDispatchedAlert] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (textToSubmit?: string) => {
    const text = (textToSubmit || commentInput).trim();
    if (!text) return;

    ensureAmapianoPlaying();
    setIsSubmitting(true);

    const isPlayTrigger = text.toUpperCase().includes('PLAY');

    const newComment: CommentItem = {
      id: `user-${Date.now()}`,
      username: 'you',
      avatar: ASSETS.creatorAvatar,
      text: text,
      timeAgo: 'Just now',
      likes: 1,
      hasDispatchedBadge: isPlayTrigger,
    };

    setComments((prev) => [...prev, newComment]);
    setCommentInput('');

    if (isPlayTrigger) {
      setTimeout(() => {
        playNotificationPing();
        setDispatchedAlert(true);
        setTimeout(() => {
          onAutoDmDispatched();
        }, 1200);
      }, 380); // Exact 0.38s latency simulation!
    } else {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="relative w-full h-full bg-[#121216] flex flex-col justify-between text-white overflow-hidden">
      {/* Dimmed backdrop blurred background - Previous BMW Image */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <img
          src={ASSETS.carDark}
          alt="BMW X7 M60i"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover blur-md"
        />
      </div>

      {/* Slide-over Comments Drawer Header */}
      <div className="relative z-10 pt-10 px-4 pb-3 border-b border-white/10 flex items-center justify-between bg-[#16161b]/95 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <span className="font-bold text-sm">Comments</span>
          <span className="text-xs text-slate-400">12,940</span>
        </div>
        <button
          onClick={() => {
            ensureAmapianoPlaying();
            onClose();
          }}
          className="p-1 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Dispatched Flash Toast Notification */}
      {dispatchedAlert && (
        <div className="relative z-30 mx-4 mt-2 p-3 rounded-xl bg-gradient-to-r from-[#183321] to-[#12281a] border border-[#76dc18] flex items-center justify-between shadow-[0_0_20px_rgba(118,220,24,0.3)] animate-pulse">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-[#76dc18] shrink-0" />
            <div className="flex flex-col">
              <span className="text-xs font-bold text-white">
                Auto-DM Dispatched in <span className="text-[#76dc18]">0.38s</span>!
              </span>
              <span className="text-[11px] text-slate-300">
                Opening direct message bot...
              </span>
            </div>
          </div>
          <Sparkles className="w-4 h-4 text-[#ffa800] animate-spin" />
        </div>
      )}

      {/* Comments List */}
      <div className="relative z-10 flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        {comments.map((comment) => (
          <div key={comment.id} className="flex items-start gap-3 text-xs">
            {/* User Avatar */}
            <div className="w-8 h-8 rounded-full overflow-hidden bg-neutral-700 shrink-0 border border-white/10">
              <img
                src={comment.avatar}
                alt={comment.username}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>

            {/* Comment Body */}
            <div className="flex-1 flex flex-col gap-1 min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="font-semibold text-white">
                  {comment.username}
                </span>
                {comment.isCreator && (
                  <span className="w-3 h-3 rounded-full bg-[#1da1f2] flex items-center justify-center text-[7px] text-white font-bold">
                    ✓
                  </span>
                )}
                {comment.isPinned && (
                  <span className="flex items-center gap-0.5 text-[10px] text-[#ffa800] font-medium bg-[#ffa800]/10 px-1.5 py-0.2 rounded">
                    <Pin className="w-2.5 h-2.5" /> Pinned
                  </span>
                )}
                <span className="text-slate-500 text-[11px]">
                  {comment.timeAgo}
                </span>
              </div>

              <p className="text-slate-200 leading-relaxed break-words">
                {comment.text}
              </p>

              {comment.hasDispatchedBadge && (
                <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#172e21] border border-[#76dc18]/30 text-[10px] text-[#76dc18] font-semibold w-fit mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#76dc18] animate-ping" />
                  Bot DM dispatched in 0.38s
                </div>
              )}
            </div>

            {/* Like Comment */}
            <button
              onClick={() => ensureAmapianoPlaying()}
              className="flex flex-col items-center gap-0.5 text-slate-500 hover:text-red-400 shrink-0 pt-1"
            >
              <Heart className="w-3.5 h-3.5" />
              <span className="text-[10px]">{comment.likes}</span>
            </button>
          </div>
        ))}
      </div>

      {/* Bottom Sticky Action & Input Area */}
      <div className="relative z-20 p-3 bg-[#18181f] border-t border-white/10 flex flex-col gap-2">
        {/* Quick Keyword Trigger Pill */}
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-slate-400">Quick simulation action:</span>
          <button
            onClick={() => handleSubmit('PLAY')}
            disabled={isSubmitting}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1d3528] border border-[#76dc18]/50 hover:bg-[#234232] text-[#76dc18] text-xs font-bold transition-all shadow-sm"
          >
            <span>⚡ Comment "PLAY"</span>
          </button>
        </div>

        {/* Text Input Row */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSubmit();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={commentInput}
            onChange={(e) => setCommentInput(e.target.value)}
            placeholder="Add a comment... (type PLAY)"
            className="flex-1 bg-[#101014] border border-white/15 focus:border-[#ffa800] rounded-full px-4 py-2 text-xs text-white placeholder-slate-500 outline-none transition-colors"
          />
          <button
            type="submit"
            disabled={!commentInput.trim() || isSubmitting}
            className={`p-2 rounded-full transition-all ${
              commentInput.trim()
                ? 'bg-[#ffa800] text-black shadow-md'
                : 'bg-white/10 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
