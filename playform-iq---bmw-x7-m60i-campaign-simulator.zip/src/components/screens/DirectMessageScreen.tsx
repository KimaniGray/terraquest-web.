import React from 'react';
import { ArrowLeft, Phone, Video, Info, Zap, ShieldCheck } from 'lucide-react';
import { ASSETS } from '@/src/data/assets';
import { playTelemetryBeep } from '@/src/utils/audio';
import { ensureAmapianoPlaying } from '@/src/utils/amapianoAudio';

interface DirectMessageScreenProps {
  onBack: () => void;
  onLaunchHud: () => void;
}

export const DirectMessageScreen: React.FC<DirectMessageScreenProps> = ({
  onBack,
  onLaunchHud,
}) => {
  const handleLaunch = () => {
    ensureAmapianoPlaying();
    playTelemetryBeep(1200, 0.15, 0.3);
    onLaunchHud();
  };

  return (
    <div className="relative w-full h-full bg-[#111115] flex flex-col justify-between text-white overflow-hidden">
      {/* DM Top Navigation Bar */}
      <div className="relative z-10 pt-10 px-3 pb-3 border-b border-white/10 flex items-center justify-between bg-[#16161c]/90 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              ensureAmapianoPlaying();
              onBack();
            }}
            className="p-1 text-slate-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          {/* Profile Header */}
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="w-8 h-8 rounded-full overflow-hidden border border-white/20">
                <img
                  src={ASSETS.creatorAvatar}
                  alt="mediamk"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = ASSETS.rawPaths.atmediamk;
                  }}
                />
              </div>
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-[#76dc18] border-2 border-[#16161c]" />
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-1">
                <span className="font-bold text-xs">mediamk</span>
                <span className="w-3 h-3 rounded-full bg-[#1da1f2] flex items-center justify-center text-[7px] text-white font-bold">
                  ✓
                </span>
              </div>
              <span className="text-[10px] text-slate-400">Active now</span>
            </div>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-3 text-slate-300">
          <Phone className="w-4 h-4 hover:text-white cursor-pointer" />
          <Video className="w-4 h-4 hover:text-white cursor-pointer" />
          <Info className="w-4 h-4 hover:text-white cursor-pointer" />
        </div>
      </div>

      {/* Message Chat Feed */}
      <div className="relative z-10 flex-1 overflow-y-auto p-4 flex flex-col gap-3">
        {/* Timestamp */}
        <div className="text-center my-1">
          <span className="text-[10px] font-medium text-slate-500 uppercase tracking-wider">
            Today 9:41 AM · Playform Auto-Dispatch
          </span>
        </div>

        {/* Incoming Bubble 1 */}
        <div className="flex items-start gap-2 max-w-[85%]">
          <div className="w-6 h-6 rounded-full overflow-hidden shrink-0 mt-1">
            <img
              src={ASSETS.creatorAvatar}
              alt="mediamk"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-3 rounded-2xl rounded-tl-sm bg-[#22222b] text-xs text-slate-100 leading-relaxed border border-white/5">
            Hey! You commented <span className="font-bold text-[#76dc18]">PLAY</span> on my BMW X7 M60i launch! 🏎️💨
          </div>
        </div>

        {/* Incoming Bubble 2 */}
        <div className="flex items-start gap-2 max-w-[85%]">
          <div className="w-6 h-6 rounded-full overflow-hidden shrink-0 mt-1 opacity-0">
            <img src={ASSETS.creatorAvatar} alt="" />
          </div>
          <div className="p-3 rounded-2xl rounded-tl-sm bg-[#22222b] text-xs text-slate-100 leading-relaxed border border-white/5">
            Here is your exclusive direct access to the Playform BMW Telemetry HUD Challenge. My track benchmark is <span className="font-bold text-[#ffa800]">1,850 pts</span>. Let's see what you've got!
          </div>
        </div>

        {/* Rich Interactive Dispatch Card */}
        <div className="flex flex-col ml-8 rounded-2xl overflow-hidden bg-[#1c1c24] border border-[#ffa800]/40 shadow-[0_8px_30px_rgba(0,0,0,0.6)]">
          {/* Card Media Preview */}
          <div className="relative h-32 w-full overflow-hidden bg-black">
            <img
              src={ASSETS.hudCockpit}
              alt="BMW HUD Preview"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1c1c24] via-transparent to-black/40" />
            
            {/* Telemetry Tag */}
            <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md border border-[#ffa800]/50 text-[10px] font-bold text-[#ffa800] uppercase tracking-wider flex items-center gap-1">
              <Zap className="w-3 h-3 fill-current" />
              BMW M-POWER HUD
            </div>

            {/* Benchmark pill */}
            <div className="absolute bottom-2 right-2.5 px-2 py-0.5 rounded bg-black/80 text-[10px] font-mono text-[#76dc18] border border-[#76dc18]/30">
              TARGET: 1,850 PTS
            </div>
          </div>

          {/* Card Body */}
          <div className="p-3.5 flex flex-col gap-2.5">
            <div>
              <h3 className="font-bold text-sm text-white font-display">
                BMW X7 Trivia Campaign
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                4.4L TwinPower V8 • 523 HP • BMW Performance Trivia HUD
              </p>
            </div>

            {/* Launch CTA Button */}
            <button
              onClick={handleLaunch}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#ffa800] to-[#ffb932] hover:brightness-110 text-black font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(255,168,0,0.35)] active:scale-[0.98]"
            >
              <span>Launch HUD Simulator</span>
              <span className="text-sm">⚡</span>
            </button>

            {/* Sub-second latency badge */}
            <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 font-medium pt-0.5">
              <ShieldCheck className="w-3 h-3 text-[#76dc18]" />
              <span>0.38s Auto-Dispatch · Zero human dropoff bottleneck</span>
            </div>
          </div>
        </div>
      </div>

      {/* Mock Chat Input Footer */}
      <div className="relative z-10 p-3 bg-[#16161c] border-t border-white/10 flex items-center gap-2 text-slate-400">
        <div className="flex-1 py-2 px-3 rounded-full bg-[#202028] text-xs text-slate-500">
          Message mediamk...
        </div>
        <div className="text-xs font-semibold text-[#ffa800]">
          Sent
        </div>
      </div>
    </div>
  );
};
