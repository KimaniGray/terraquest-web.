import React, { useState } from 'react';
import { Gauge, Zap, Trophy, CheckCircle2, ArrowRight } from 'lucide-react';
import { QUIZ_QUESTIONS, CAMPAIGN_METRICS } from '@/src/data/campaign';
import { ASSETS } from '@/src/data/assets';
import { playTelemetryBeep, playVictoryChime, playEngineRev } from '@/src/utils/audio';
import { ensureAmapianoPlaying } from '@/src/utils/amapianoAudio';

interface HudQuizScreenProps {
  onComplete: (finalScore: number) => void;
}

export const HudQuizScreen: React.FC<HudQuizScreenProps> = ({ onComplete }) => {
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [score, setScore] = useState(1350);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerCorrect, setIsAnswerCorrect] = useState<boolean | null>(null);
  const [showScoreBonus, setShowScoreBonus] = useState(false);
  const [completed, setCompleted] = useState(false);

  const currentQ = QUIZ_QUESTIONS[currentQIndex];

  const handleSelectOption = (index: number) => {
    if (selectedOption !== null) return; // Prevent double clicks
    ensureAmapianoPlaying();
    setSelectedOption(index);

    const isCorrect = index === currentQ.correctIndex;
    setIsAnswerCorrect(isCorrect);

    if (isCorrect) {
      playTelemetryBeep(1500, 0.1, 0.3);
      playEngineRev();
      setShowScoreBonus(true);
      const newScore = score + currentQ.pts;
      setScore(newScore);

      setTimeout(() => {
        setShowScoreBonus(false);
        if (currentQIndex < QUIZ_QUESTIONS.length - 1) {
          setCurrentQIndex((prev) => prev + 1);
          setSelectedOption(null);
          setIsAnswerCorrect(null);
        } else {
          // Completed quiz and beat benchmark!
          playVictoryChime();
          setCompleted(true);
        }
      }, 900);
    } else {
      setTimeout(() => {
        setSelectedOption(null);
        setIsAnswerCorrect(null);
      }, 700);
    }
  };

  const handleFinish = () => {
    ensureAmapianoPlaying();
    onComplete(score);
  };

  return (
    <div className="relative w-full h-full bg-[#0a0a0d] flex flex-col justify-between text-white overflow-hidden select-none font-sans">
      {/* Background HUD Cockpit Ambience */}
      <div className="absolute inset-0 pointer-events-none opacity-25">
        <img
          src={ASSETS.hudCockpit}
          alt="BMW M Cockpit"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0d]/80 via-transparent to-[#0a0a0d]" />
      </div>

      {/* Top HUD Cluster Telemetry Display */}
      <div className="relative z-10 pt-10 px-4 pb-2 border-b border-white/10 bg-[#121217]/90 backdrop-blur-md flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#76dc18] animate-ping" />
            <span className="text-[10px] font-mono tracking-widest text-[#76dc18] uppercase">
              BMW M-HUD TELEMETRY
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400">
              Q {currentQIndex + 1}/{QUIZ_QUESTIONS.length}
            </span>
          </div>
        </div>

        {/* Live Gauges Row */}
        <div className="grid grid-cols-3 gap-2 py-1">
          {/* Speedometer */}
          <div className="p-2 rounded-xl bg-[#181822] border border-white/5 flex flex-col items-center">
            <span className="text-[9px] uppercase tracking-wider text-slate-400">Speed</span>
            <span className="text-sm font-bold font-mono text-white tabular-nums">
              142 <span className="text-[9px] text-slate-400 font-normal">MPH</span>
            </span>
          </div>

          {/* Gear / Mode */}
          <div className="p-2 rounded-xl bg-[#181822] border border-[#ffa800]/30 flex flex-col items-center">
            <span className="text-[9px] uppercase tracking-wider text-[#ffa800]">M-Mode</span>
            <span className="text-sm font-bold font-mono text-[#ffa800]">
              M5 <span className="text-[9px] text-[#76dc18]">SPORT+</span>
            </span>
          </div>

          {/* Current Score */}
          <div className="p-2 rounded-xl bg-[#181822] border border-white/5 flex flex-col items-center relative overflow-hidden">
            <span className="text-[9px] uppercase tracking-wider text-slate-400">Score</span>
            <span className="text-sm font-bold font-mono text-white tabular-nums">
              {score} <span className="text-[9px] text-slate-400 font-normal">pts</span>
            </span>
            {showScoreBonus && (
              <span className="absolute inset-0 bg-[#76dc18]/30 flex items-center justify-center font-bold text-xs text-[#76dc18] animate-bounce font-mono">
                +{currentQ.pts} PTS!
              </span>
            )}
          </div>
        </div>

        {/* Benchmark Progress Tracker */}
        <div className="flex flex-col gap-1 pt-1">
          <div className="flex items-center justify-between text-[10px] font-mono">
            <span className="text-slate-400">
              Benchmark Target: {CAMPAIGN_METRICS.benchmarkPts} pts
            </span>
            <span
              className={
                score > CAMPAIGN_METRICS.benchmarkPts
                  ? 'text-[#76dc18] font-bold'
                  : 'text-[#ffa800]'
              }
            >
              {score > CAMPAIGN_METRICS.benchmarkPts
                ? `CRUSHED (+${score - CAMPAIGN_METRICS.benchmarkPts})`
                : `${CAMPAIGN_METRICS.benchmarkPts - score} pts to beat`}
            </span>
          </div>
          <div className="w-full h-1.5 rounded-full bg-[#202028] overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                score > CAMPAIGN_METRICS.benchmarkPts
                  ? 'bg-gradient-to-r from-[#ffa800] to-[#76dc18]'
                  : 'bg-[#ffa800]'
              }`}
              style={{
                width: `${Math.min(100, (score / 2000) * 100)}%`,
              }}
            />
          </div>
        </div>
      </div>

      {/* Main Interactive Quiz Section */}
      <div className="relative z-10 flex-1 p-4 flex flex-col justify-center">
        {!completed ? (
          <div className="flex flex-col gap-4">
            {/* Category and telemetry badge */}
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#ffa800] px-2 py-0.5 rounded bg-[#ffa800]/10 border border-[#ffa800]/20">
                {currentQ.category}
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                {currentQ.telemetryMetric}
              </span>
            </div>

            {/* Question Text */}
            <h3 className="text-sm font-semibold text-white leading-snug font-display">
              {currentQ.question}
            </h3>

            {/* Options list */}
            <div className="flex flex-col gap-2 mt-1">
              {currentQ.options.map((option, idx) => {
                const isChosen = selectedOption === idx;
                const isCorrect = idx === currentQ.correctIndex;

                let btnStyle = 'bg-[#181822] border-white/10 hover:border-white/20 text-slate-200';
                if (isChosen) {
                  if (isAnswerCorrect) {
                    btnStyle = 'bg-[#1a3824] border-[#76dc18] text-[#76dc18] scale-[1.01] shadow-[0_0_15px_rgba(118,220,24,0.3)]';
                  } else {
                    btnStyle = 'bg-[#3b1c1c] border-red-500 text-red-300';
                  }
                }

                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    disabled={selectedOption !== null}
                    className={`w-full p-3 rounded-xl border text-left text-xs font-medium transition-all flex items-center justify-between ${btnStyle}`}
                  >
                    <span>{option}</span>
                    {isChosen && isAnswerCorrect && (
                      <CheckCircle2 className="w-4 h-4 text-[#76dc18] shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          /* Victory Completion State */
          <div className="flex flex-col items-center text-center gap-3 p-4 rounded-2xl bg-[#181822]/90 border border-[#76dc18]/50 shadow-[0_0_30px_rgba(118,220,24,0.2)] animate-in fade-in">
            <div className="w-14 h-14 rounded-full bg-[#1e3828] border-2 border-[#76dc18] flex items-center justify-center text-[#76dc18] shadow-lg">
              <Trophy className="w-7 h-7" />
            </div>

            <div className="flex flex-col gap-1">
              <span className="text-[11px] uppercase tracking-widest font-mono text-[#76dc18] font-bold">
                BENCHMARK BEATEN!
              </span>
              <h3 className="text-xl font-bold text-white font-display">
                {score} PTS
              </h3>
              <p className="text-xs text-slate-300 max-w-[220px]">
                You surpassed @mediamk's 1,850 pts mark! VIP M-Power Reward Unlocked.
              </p>
            </div>

            <button
              onClick={handleFinish}
              className="mt-2 w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#76dc18] to-[#9eff36] text-black font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-[0_0_20px_rgba(118,220,24,0.4)] hover:brightness-110 active:scale-95 transition-all"
            >
              <span>Claim VIP Viral Reward</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Bottom HUD Status Ribbon */}
      <div className="relative z-10 px-4 py-2.5 bg-[#121217] border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400 font-mono">
        <div className="flex items-center gap-1">
          <Gauge className="w-3 h-3 text-[#ffa800]" />
          <span>xDrive AWD Telemetry Active</span>
        </div>
        <div className="flex items-center gap-1 text-[#76dc18]">
          <Zap className="w-3 h-3" />
          <span>0.38s Playform Engine</span>
        </div>
      </div>
    </div>
  );
};
