import React from 'react';
import {
  Wifi,
  Battery,
} from 'lucide-react';
import { ReelScreen } from './screens/ReelScreen';
import { CommentsScreen } from './screens/CommentsScreen';
import { DirectMessageScreen } from './screens/DirectMessageScreen';
import { HudQuizScreen } from './screens/HudQuizScreen';
import { ViralRewardScreen } from './screens/ViralRewardScreen';
import { ensureAmapianoPlaying } from '@/src/utils/amapianoAudio';

interface PhoneSimulatorProps {
  currentStep: number;
  onStepChange: (step: number) => void;
  userScore: number;
  setUserScore: (score: number) => void;
}

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({
  currentStep,
  onStepChange,
  userScore,
  setUserScore,
}) => {
  const handleStepTransition = (newStep: number) => {
    ensureAmapianoPlaying();
    onStepChange(newStep);
  };

  return (
    <div className="relative flex items-center justify-center py-2 px-1 select-none">
      {/* Outer Phone Hardware Frame (Ultra-tight bezel fit, steady, NO flashing) */}
      <div className="relative w-[345px] sm:w-[380px] h-[720px] sm:h-[755px] rounded-[48px] p-[7px] bg-gradient-to-b from-[#34343d] via-[#1a1a20] to-[#101014] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.95)] border border-white/10">
        {/* Hardware Side Buttons */}
        <div className="absolute -left-[3px] top-[115px] w-[3px] h-[26px] bg-[#3a3a44] rounded-l-sm" />
        <div className="absolute -left-[3px] top-[160px] w-[3px] h-[48px] bg-[#3a3a44] rounded-l-sm" />
        <div className="absolute -left-[3px] top-[220px] w-[3px] h-[48px] bg-[#3a3a44] rounded-l-sm" />
        <div className="absolute -right-[3px] top-[175px] w-[3px] h-[75px] bg-[#3a3a44] rounded-r-sm" />

        {/* Screen Glass Bezel (Full Bleed Tight Edge Fit) */}
        <div className="relative w-full h-full rounded-[42px] overflow-hidden bg-black flex flex-col">
          {/* iOS Status Bar & Clean Dynamic Island Pill (Zero Music Writing, Zero Flashing) */}
          <div className="absolute top-0 inset-x-0 z-50 px-6 pt-2.5 flex items-center justify-between pointer-events-none text-white text-xs font-semibold">
            {/* Left: Clock */}
            <span className="font-sans text-[12px] tracking-tight">9:41</span>

            {/* Center: Authentic Dynamic Island Cutout (No text, No flashing) */}
            <div className="w-[105px] h-[26px] bg-black rounded-full flex items-center justify-between px-2.5 border border-white/5 shadow-inner">
              <div className="w-2.5 h-2.5 rounded-full bg-[#121218] border border-white/10" />
              <div className="w-2 h-2 rounded-full bg-[#0a0a0e]" />
            </div>

            {/* Right: Cellular, Wifi, Battery */}
            <div className="flex items-center gap-1.5 text-white/90">
              <div className="flex items-end gap-0.5 h-2.5">
                <span className="w-0.5 h-1 bg-white rounded-full" />
                <span className="w-0.5 h-1.5 bg-white rounded-full" />
                <span className="w-0.5 h-2 bg-white rounded-full" />
                <span className="w-0.5 h-2.5 bg-white rounded-full" />
              </div>
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-4 h-4 fill-white" />
            </div>
          </div>

          {/* Screen Content Container (tight edge-to-edge layout, seamless screen transitions) */}
          <div className="w-full h-full relative">
            {currentStep === 1 && (
              <ReelScreen
                onOpenComments={() => handleStepTransition(2)}
                onLaunchChallenge={() => handleStepTransition(4)}
              />
            )}

            {currentStep === 2 && (
              <CommentsScreen
                onAutoDmDispatched={() => handleStepTransition(3)}
                onClose={() => handleStepTransition(1)}
              />
            )}

            {currentStep === 3 && (
              <DirectMessageScreen
                onBack={() => handleStepTransition(2)}
                onLaunchHud={() => handleStepTransition(4)}
              />
            )}

            {currentStep === 4 && (
              <HudQuizScreen
                onComplete={(score) => {
                  setUserScore(score);
                  handleStepTransition(5);
                }}
              />
            )}

            {currentStep === 5 && (
              <ViralRewardScreen
                score={userScore}
                onRestart={() => handleStepTransition(1)}
              />
            )}
          </div>

          {/* iOS Home Indicator Bar */}
          <div className="absolute bottom-1.5 inset-x-0 flex justify-center z-50 pointer-events-none">
            <div className="w-32 h-1 rounded-full bg-white/40 backdrop-blur-md" />
          </div>
        </div>
      </div>
    </div>
  );
};
