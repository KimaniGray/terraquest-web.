import React from 'react';
import { CAMPAIGN_METRICS } from '@/src/data/campaign';
import { ASSETS } from '@/src/data/assets';

interface HeaderProps {
  currentStep: number;
}

export const Header: React.FC<HeaderProps> = () => {
  return (
    <header className="w-full flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-3 px-4 sm:px-6 lg:px-8 border-b border-white/10 bg-[#121216]/95 backdrop-blur-md sticky top-0 z-40">
      {/* Brand & Campaign Title */}
      <div className="flex items-center gap-3">
        {/* Playform IQ Official Logo Badge */}
        <div className="flex items-center px-3 py-1.5 rounded-xl bg-white shadow-[0_2px_12px_rgba(0,0,0,0.3)] border border-white/80 hover:brightness-105 transition-all">
          <img
            src={ASSETS.playformLogo}
            alt="Playform IQ"
            className="h-6 w-auto object-contain"
            onError={(e) => {
              (e.target as HTMLImageElement).src = '/playformiq-logo.svg';
            }}
          />
        </div>

        <div className="h-5 w-px bg-white/15 hidden sm:block" />

        {/* Live Campaign Simulator Status */}
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#76dc18]"></span>
            </span>
            <span className="text-[11px] font-bold tracking-wider uppercase text-[#76dc18]">
              Live Campaign Simulator
            </span>
          </div>
          <h1 className="text-sm font-semibold text-white/90 font-display tracking-tight">
            {CAMPAIGN_METRICS.name}
          </h1>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
        <div className="flex flex-col px-3 py-1 rounded-lg bg-[#181820] border border-white/5">
          <span className="text-[9px] uppercase tracking-wider text-slate-400 font-medium">
            Benchmark
          </span>
          <div className="text-xs font-bold text-white flex items-center gap-1 tabular-nums">
            <span className="text-[#ffa800]">{CAMPAIGN_METRICS.benchmarkPts.toLocaleString()} pts</span>
            <span className="text-slate-400 font-normal text-[10px]">({CAMPAIGN_METRICS.creatorHandle})</span>
          </div>
        </div>

        <div className="flex flex-col px-3 py-1 rounded-lg bg-[#181820] border border-white/5">
          <span className="text-[9px] uppercase tracking-wider text-slate-400 font-medium">
            Auto-Dispatch
          </span>
          <div className="text-xs font-bold text-[#76dc18] tabular-nums">
            {CAMPAIGN_METRICS.autoDispatchLatency}
          </div>
        </div>

        <div className="flex flex-col px-3 py-1 rounded-lg bg-[#181820] border border-white/5">
          <span className="text-[9px] uppercase tracking-wider text-slate-400 font-medium">
            Engagement Rate
          </span>
          <div className="text-xs font-bold text-[#ffa800] tabular-nums">
            {CAMPAIGN_METRICS.engagementRate}
          </div>
        </div>
      </div>
    </header>
  );
};
