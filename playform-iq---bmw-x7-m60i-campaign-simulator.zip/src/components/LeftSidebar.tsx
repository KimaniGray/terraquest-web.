import React from 'react';
import {
  ChevronRight,
  ArrowLeft,
  ArrowRight,
  Check,
  Zap,
  Target,
} from 'lucide-react';
import { FUNNEL_STEPS, CAMPAIGN_METRICS } from '@/src/data/campaign';
import { ensureAmapianoPlaying } from '@/src/utils/amapianoAudio';

interface LeftSidebarProps {
  currentStep: number;
  onSelectStep: (stepId: number) => void;
  onNext: () => void;
  onPrev: () => void;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  currentStep,
  onSelectStep,
  onNext,
  onPrev,
}) => {
  const handleSelectStep = (stepId: number) => {
    ensureAmapianoPlaying();
    onSelectStep(stepId);
  };

  const handlePrevStep = () => {
    ensureAmapianoPlaying();
    onPrev();
  };

  const handleNextStep = () => {
    ensureAmapianoPlaying();
    onNext();
  };

  return (
    <aside className="w-full lg:w-[320px] flex flex-col gap-4 shrink-0">
      {/* Campaign Funnel Panel */}
      <div className="flex flex-col gap-3">
        {/* Section Title */}
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs uppercase font-bold tracking-widest text-slate-300 font-display">
            Campaign Funnel
          </h2>
          <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[#1e2926] text-[#76dc18] border border-[#76dc18]/20">
            5 Steps
          </span>
        </div>

        {/* 5 Funnel Step Cards (No haptic tone on click) */}
        <div className="flex flex-col gap-2">
          {FUNNEL_STEPS.map((step) => {
            const isActive = currentStep === step.id;
            const isCompleted = currentStep > step.id;

            return (
              <button
                key={step.id}
                onClick={() => handleSelectStep(step.id)}
                className={`w-full flex items-center justify-between p-3 rounded-xl text-left transition-all duration-200 border ${
                  isActive
                    ? 'bg-[#222228] border-[#ffa800]/50 shadow-[0_0_20px_rgba(255,168,0,0.12)]'
                    : 'bg-[#18181c]/80 hover:bg-[#202026] border-white/5 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  {/* Step Number Badge */}
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 transition-colors ${
                      isActive
                        ? 'bg-[#ffa800] text-black shadow-sm'
                        : isCompleted
                        ? 'bg-[#1b2f28] text-[#76dc18] border border-[#76dc18]/30'
                        : 'bg-[#24242c] text-slate-400'
                    }`}
                  >
                    {isCompleted ? <Check className="w-4 h-4 stroke-[3]" /> : step.id}
                  </div>

                  {/* Step Info */}
                  <div className="flex flex-col min-w-0">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs font-bold truncate ${
                          isActive ? 'text-white' : 'text-slate-200'
                        }`}
                      >
                        {step.title}
                      </span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-white/5 text-slate-400 font-mono shrink-0">
                        {step.tag}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 truncate mt-0.5">
                      {step.shortDesc}
                    </span>
                  </div>
                </div>

                <ChevronRight
                  className={`w-4 h-4 shrink-0 transition-transform ${
                    isActive ? 'text-[#ffa800] translate-x-0.5' : 'text-slate-600'
                  }`}
                />
              </button>
            );
          })}
        </div>

        {/* Step Navigation Quick Action Bar */}
        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={handlePrevStep}
            disabled={currentStep === 1}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl text-xs font-semibold border transition-all ${
              currentStep === 1
                ? 'opacity-40 cursor-not-allowed bg-[#18181c] border-white/5 text-slate-500'
                : 'bg-[#1e1e24] hover:bg-[#26262e] border-white/10 text-white hover:border-white/20'
            }`}
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Prev
          </button>

          <button
            onClick={handleNextStep}
            disabled={currentStep === 5}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl text-xs font-bold transition-all shadow-md ${
              currentStep === 5
                ? 'opacity-40 cursor-not-allowed bg-[#ffa800]/50 text-black'
                : 'bg-[#ffa800] hover:bg-[#ffb932] text-black shadow-[0_0_15px_rgba(255,168,0,0.25)] hover:scale-[1.02] active:scale-[0.98]'
            }`}
          >
            Next
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Campaign Architecture Overview Card (Clean, No Music Writing) */}
      <div className="p-4 rounded-2xl bg-[#16161c] border border-white/10 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="text-xs uppercase font-bold tracking-wider text-white font-display flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-[#ffa800]" />
            Workflow Engine
          </span>
          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-[#1b2e23] text-[#76dc18] border border-[#76dc18]/30">
            AUTO-SYNC
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-left">
          <div className="p-2.5 rounded-xl bg-[#121217] border border-white/5 flex flex-col">
            <span className="text-[10px] text-slate-400 font-mono">LATENCY</span>
            <span className="text-xs font-bold text-[#76dc18]">{CAMPAIGN_METRICS.autoDispatchLatency}</span>
          </div>
          <div className="p-2.5 rounded-xl bg-[#121217] border border-white/5 flex flex-col">
            <span className="text-[10px] text-slate-400 font-mono">RETENTION</span>
            <span className="text-xs font-bold text-[#ffa800]">{CAMPAIGN_METRICS.completionRate}</span>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-[#121217] border border-white/5 flex items-center justify-between text-xs">
          <span className="text-slate-400 flex items-center gap-1.5">
            <Target className="w-3.5 h-3.5 text-slate-300" />
            Lead Benchmark
          </span>
          <span className="font-bold text-white font-mono">
            {CAMPAIGN_METRICS.benchmarkPts.toLocaleString()} pts
          </span>
        </div>
      </div>
    </aside>
  );
};
