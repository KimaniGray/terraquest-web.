import React, { useState } from 'react';
import { Header } from './components/Header';
import { LeftSidebar } from './components/LeftSidebar';
import { PhoneSimulator } from './components/PhoneSimulator';
import { RightSidebar } from './components/RightSidebar';

export default function App() {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [userScore, setUserScore] = useState<number>(1940);

  const handleNext = () => {
    if (currentStep < 5) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  return (
    <div className="min-h-screen bg-[#121214] text-[#e2e2e2] flex flex-col font-sans selection:bg-[#ffa800]/20 selection:text-white relative overflow-x-hidden">
      {/* Ambient background glows matching Obsidian Kinetic theme */}
      <div className="fixed top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-gradient-to-tr from-[#ffa800]/5 via-transparent to-[#76dc18]/5 rounded-full blur-[140px] pointer-events-none" />

      {/* Top Header */}
      <Header currentStep={currentStep} />

      {/* Main Campaign Simulator Canvas */}
      <main className="flex-1 max-w-[1560px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8 flex flex-col lg:flex-row items-center lg:items-start justify-center gap-8 xl:gap-12">
        {/* Left Column: Funnel Steps & Audio Haptics */}
        <div className="w-full lg:w-auto flex justify-center lg:justify-start order-2 lg:order-1">
          <LeftSidebar
            currentStep={currentStep}
            onSelectStep={setCurrentStep}
            onNext={handleNext}
            onPrev={handlePrev}
          />
        </div>

        {/* Center Column: Interactive Smartphone Mockup */}
        <div className="w-full lg:flex-1 flex justify-center order-1 lg:order-2">
          <PhoneSimulator
            currentStep={currentStep}
            onStepChange={setCurrentStep}
            userScore={userScore}
            setUserScore={setUserScore}
          />
        </div>

        {/* Right Column: Funnel Conversions & Partner Integrations */}
        <div className="w-full lg:w-auto flex justify-center lg:justify-end order-3">
          <RightSidebar />
        </div>
      </main>
    </div>
  );
}
