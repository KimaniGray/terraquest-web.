# PlayformIQ Showcase Prototype

Open index.html in a browser.

Five products are demonstrated with intentionally different interaction patterns:
- LaunchIQ — Kivuli Motors: build/discover
- LearningIQ — JuaFuel: diagnose/solve
- ProductIQ — MajiFresh: build/match
- EventsIQ — Sauti360: explore/collect/compete
- RewardIQ — PesaLinka: complete/collect/unlock

The brands are fictional and the experiences are illustrative demonstrations, not customer case studies.
